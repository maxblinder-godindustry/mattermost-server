# config.json

This is the system configuration file for your Mattermost server. Settings are specific to different editions of Mattermost. Please read the documentation before making changes: https://docs.mattermost.com/configure/configuration-settings.html/
